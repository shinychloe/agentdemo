from gradio_client.cli import deploy_discord

__all__ = ["deploy_discord"]
